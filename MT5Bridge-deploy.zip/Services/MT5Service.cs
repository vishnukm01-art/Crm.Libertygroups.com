using System.Reflection;
using Microsoft.Extensions.Options;
using MT5Bridge.Models;

namespace MT5Bridge.Services;

/// <summary>
/// MT5 Manager API service implementation.
/// 
/// This service dynamically loads the MT5ManagerAPI.NET.dll and uses reflection
/// to call the Manager API methods. This approach allows the bridge to compile
/// without the DLL present (it's only needed at runtime on the server).
///
/// IMPORTANT: The MT5 Manager API is NOT thread-safe.
/// All DLL calls are serialized through _apiLock (SemaphoreSlim).
///
/// Required DLLs in the application directory or libs/ folder:
///   - MT5APIManager64.dll (native C++ DLL)
///   - MT5ManagerAPI.NET.dll (managed .NET wrapper)
/// </summary>
public class MT5Service : IMT5Service, IDisposable
{
    private readonly ILogger<MT5Service> _logger;
    private readonly BridgeOptions _options;
    private readonly SemaphoreSlim _apiLock = new(1, 1);

    // MT5 Manager API objects loaded via reflection
    private Assembly? _managerAssembly;
    private object? _managerApi;
    private bool _connected;
    private DateTime? _lastConnected;
    private DateTime? _lastKeepalive;
    private string _lastError = "";
    private long _totalRequests;
    private readonly DateTime _startTime = DateTime.UtcNow;

    public bool IsConnected => _connected;

    public MT5Service(ILogger<MT5Service> logger, IOptions<BridgeOptions> options)
    {
        _logger = logger;
        _options = options.Value;
    }

    public async Task<bool> ConnectAsync(CancellationToken ct = default)
    {
        await _apiLock.WaitAsync(ct);
        try
        {
            // Step 1: Load the MT5 Manager API assembly
            if (_managerAssembly == null)
            {
                var dllPath = FindManagerDll();
                if (dllPath == null)
                {
                    _lastError = "MetaQuotes.MT5ManagerAPI64.dll not found.";
                    _logger.LogError(_lastError);
                    return false;
                }

                _logger.LogInformation("Loading MT5 Manager API from: {Path}", dllPath);
                _managerAssembly = Assembly.LoadFrom(dllPath);
                _logger.LogInformation("MT5 Manager API assembly loaded. Types: {Types}",
                    string.Join(", ", _managerAssembly.GetExportedTypes().Select(t => t.Name).Take(30)));
            }

            // Step 2: Find and initialize the factory
            // Factory is SMTManagerAPIFactory with:
            //   Initialize(string dll_path) -> MTRetCode
            //   CreateManager(uint version, MTRetCode& res) -> CIMTManagerAPI
            //   CreateManager(uint version, string data_path, MTRetCode& res) -> CIMTManagerAPI
            var factoryType = FindType(_managerAssembly, "ManagerAPIFactory");
            if (factoryType == null)
            {
                _lastError = "Could not find ManagerAPIFactory type in MT5 assembly. " +
                    $"Available types: {string.Join(", ", _managerAssembly.GetExportedTypes().Select(t => t.Name))}";
                _logger.LogError(_lastError);
                return false;
            }
            _logger.LogInformation("Found factory type: {Type}", factoryType.FullName);

            // Step 2a: Call Initialize(dll_path) to tell the factory where native DLLs are
            var initMethod = factoryType.GetMethod("Initialize", BindingFlags.Static | BindingFlags.Public);
            if (initMethod != null)
            {
                var dllDir = Path.GetDirectoryName(FindManagerDll()) ?? AppContext.BaseDirectory;
                _logger.LogInformation("Calling factory Initialize with path: {Path}", dllDir);
                var initResult = initMethod.Invoke(null, new object[] { dllDir });
                _logger.LogInformation("Factory Initialize returned: {Result}", initResult);
                if (!IsRetCodeSuccess(initResult))
                {
                    _lastError = $"Factory Initialize failed: {initResult}";
                    _logger.LogError(_lastError);
                    return false;
                }
            }

            // Step 2b: Call CreateManager - prefer the 2-param overload (version, out res)
            var createMethods = factoryType.GetMethods(BindingFlags.Static | BindingFlags.Public)
                .Where(m => m.Name == "CreateManager")
                .OrderBy(m => m.GetParameters().Length)
                .ToList();

            if (createMethods.Count == 0)
            {
                _lastError = $"No CreateManager method on {factoryType.Name}. " +
                    $"Methods: {string.Join(", ", factoryType.GetMethods().Select(m => m.Name))}";
                _logger.LogError(_lastError);
                return false;
            }

            // Use the overload with fewest params (version, res)
            var createMethod = createMethods.First();
            var parameters = createMethod.GetParameters();
            _logger.LogInformation("Using CreateManager overload with {Count} params: {Params}",
                parameters.Length,
                string.Join(", ", parameters.Select(p => $"{p.ParameterType.Name} {p.Name} (IsOut={p.IsOut})")));

            var args = new object?[parameters.Length];
            for (int i = 0; i < parameters.Length; i++)
            {
                var pType = parameters[i].ParameterType;
                var pName = parameters[i].Name?.ToLower() ?? "";

                if (pType == typeof(uint))
                    args[i] = (uint)5660;
                else if (pType == typeof(string))
                    args[i] = AppContext.BaseDirectory; // data_path
                else if (parameters[i].IsOut)
                {
                    // For out MTRetCode& parameter, initialize with default
                    var elementType = pType.IsByRef ? pType.GetElementType()! : pType;
                    args[i] = Activator.CreateInstance(elementType);
                }
            }

            // CreateManager RETURNS the manager object; res out param is the error code
            var managerResult = createMethod.Invoke(null, args);
            _logger.LogInformation("CreateManager returned: {Type} = {Value}",
                managerResult?.GetType().FullName ?? "null", managerResult);

            // Get the res (MTRetCode) from the out parameter
            object? retCode = null;
            for (int i = 0; i < parameters.Length; i++)
            {
                if (parameters[i].IsOut)
                {
                    retCode = args[i];
                    _logger.LogInformation("CreateManager out param [{Index}] ({Name}): {Value}",
                        i, parameters[i].Name, args[i]);
                }
            }

            // The RETURN VALUE is the CIMTManagerAPI object
            _managerApi = managerResult;

            if (_managerApi == null)
            {
                _lastError = $"CreateManager returned null. RetCode: {retCode}";
                _logger.LogError(_lastError);
                return false;
            }

            _logger.LogInformation("Manager API created. Type: {Type}",
                _managerApi.GetType().FullName);

            // Step 3: Connect to the MT5 server
            // Signature: Connect(String server, UInt64 login, String password,
            //                    String password_cert, EnPumpModes pump_mode, UInt32 timeout) -> MTRetCode
            var connectMethod = _managerApi.GetType().GetMethod("Connect");
            if (connectMethod == null)
            {
                // Search more broadly
                connectMethod = _managerApi.GetType().GetMethods()
                    .FirstOrDefault(m => m.Name.Equals("Connect", StringComparison.OrdinalIgnoreCase));
            }

            if (connectMethod == null)
            {
                var allMethods = _managerApi.GetType()
                    .GetMethods(BindingFlags.Public | BindingFlags.Instance)
                    .Select(m => m.Name).Distinct().OrderBy(n => n).ToList();
                _lastError = $"No Connect method on {_managerApi.GetType().FullName}. " +
                    $"Methods ({allMethods.Count}): [{string.Join(", ", allMethods)}]";
                _logger.LogError(_lastError);
                return false;
            }

            var connectParams = connectMethod.GetParameters();
            _logger.LogInformation("Connect method: {Params}",
                string.Join(", ", connectParams.Select(p => $"{p.ParameterType.Name} {p.Name}")));

            var server = $"{_options.MT5Server}:{_options.MT5Port}";
            _logger.LogInformation("Connecting to {Server} with login {Login}", server, _options.ManagerLogin);

            // Build Connect arguments matching the exact signature
            var connectArgs = new object?[connectParams.Length];
            for (int i = 0; i < connectParams.Length; i++)
            {
                var pName = connectParams[i].Name?.ToLower() ?? "";
                var pType = connectParams[i].ParameterType;

                if (pName.Contains("server") || pName.Contains("address"))
                    connectArgs[i] = server;
                else if (pName.Contains("login"))
                    connectArgs[i] = (ulong)_options.ManagerLogin;
                else if (pName == "password")
                    connectArgs[i] = _options.ManagerPassword;
                else if (pName.Contains("password_cert") || pName.Contains("cert"))
                    connectArgs[i] = "";
                else if (pName.Contains("pump") || pName.Contains("mode"))
                {
                    // EnPumpModes - use 0 for no pump (we don't need real-time updates)
                    if (pType.IsEnum)
                        connectArgs[i] = Enum.ToObject(pType, 0);
                    else
                        connectArgs[i] = Convert.ChangeType(0, pType);
                }
                else if (pName.Contains("timeout"))
                    connectArgs[i] = (uint)30000; // 30 second timeout
                else if (pType == typeof(string))
                    connectArgs[i] = "";
                else if (pType == typeof(uint))
                    connectArgs[i] = (uint)0;
                else if (pType == typeof(ulong))
                    connectArgs[i] = (ulong)0;
            }

            _logger.LogInformation("Calling Connect with args: {Args}",
                string.Join(", ", connectArgs.Select((a, idx) => $"{connectParams[idx].Name}={a}")));

            var connectResult = connectMethod.Invoke(_managerApi, connectArgs);
            _logger.LogInformation("Connect result: {Result}", connectResult);

            var isSuccess = IsRetCodeSuccess(connectResult);

            if (isSuccess)
            {
                _connected = true;
                _lastConnected = DateTime.UtcNow;
                _lastError = "";
                _logger.LogInformation("Successfully connected to MT5 server");
            }
            else
            {
                _lastError = $"MT5 Connect failed: {connectResult}";
                _logger.LogError(_lastError);
                _connected = false;
            }

            return _connected;
        }
        catch (Exception ex)
        {
            _lastError = $"Connection error: {ex.InnerException?.Message ?? ex.Message}";
            _logger.LogError(ex, "Failed to connect to MT5 server");
            _connected = false;
            return false;
        }
        finally
        {
            _apiLock.Release();
        }
    }

    public void Disconnect()
    {
        try
        {
            if (_managerApi != null)
            {
                var disconnectMethod = _managerApi.GetType().GetMethod("Disconnect");
                disconnectMethod?.Invoke(_managerApi, null);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error during disconnect");
        }
        _connected = false;
    }

    public async Task<bool> KeepaliveAsync(CancellationToken ct = default)
    {
        if (!_connected || _managerApi == null) return false;

        await _apiLock.WaitAsync(ct);
        try
        {
            // Try to call a lightweight method to verify connection
            var timeMethod = _managerApi.GetType().GetMethods()
                .FirstOrDefault(m => m.Name.Contains("TimeServer") || m.Name.Contains("ServerTime"));

            if (timeMethod != null)
            {
                var result = timeMethod.Invoke(_managerApi, null);
                _lastKeepalive = DateTime.UtcNow;
                return true;
            }

            // Fallback: try any simple getter
            _lastKeepalive = DateTime.UtcNow;
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Keepalive failed, marking disconnected");
            _connected = false;
            _lastError = $"Keepalive failed: {ex.Message}";
            return false;
        }
        finally
        {
            _apiLock.Release();
        }
    }

    public HealthStatus GetStatus() => new()
    {
        Connected = _connected,
        Mode = "bridge",
        LastError = string.IsNullOrEmpty(_lastError) ? null : _lastError,
        LastConnected = _lastConnected,
        LastKeepalive = _lastKeepalive,
        TotalRequests = _totalRequests,
        ServerBuild = "5660",
        Uptime = DateTime.UtcNow - _startTime
    };

    // ─── User Operations ─────────────────────────────────────

    public async Task<BridgeResult<UserResponse>> CreateUser(CreateUserRequest request)
    {
        return await CallApi<UserResponse>("CreateUser", async () =>
        {
            // Get a user record object from the API
            var userRecord = CreateRecord("User");
            if (userRecord == null)
                return BridgeResult<UserResponse>.Fail("Could not create MT5 user record object");

            // Set user fields
            SetProperty(userRecord, "Name", request.Name);
            SetProperty(userRecord, "Email", request.Email);
            SetProperty(userRecord, "Group", request.Group);
            SetProperty(userRecord, "Leverage", (uint)request.Leverage);
            SetProperty(userRecord, "MainPassword", request.MainPassword);
            SetProperty(userRecord, "Phone", request.Phone);
            SetProperty(userRecord, "Country", request.Country);

            // Call UserAdd
            var result = InvokeMethod("UserAdd", userRecord);
            if (!IsRetCodeSuccess(result))
                return BridgeResult<UserResponse>.Fail($"UserAdd failed: {result}", 400);

            // Read back the created user data
            return BridgeResult<UserResponse>.Ok(MapUserResponse(userRecord));
        });
    }

    public async Task<BridgeResult<UserResponse>> GetUser(long login)
    {
        return await CallApi<UserResponse>("GetUser", async () =>
        {
            var userRecord = CreateRecord("User");
            if (userRecord == null)
                return BridgeResult<UserResponse>.Fail("Could not create MT5 user record object");

            var result = InvokeMethod("UserGet", (ulong)login, userRecord);
            if (!IsRetCodeSuccess(result))
                return BridgeResult<UserResponse>.Fail($"UserGet failed: {result}", 404);

            return BridgeResult<UserResponse>.Ok(MapUserResponse(userRecord));
        });
    }

    public async Task<BridgeResult<object>> UpdateUser(UpdateUserRequest request)
    {
        return await CallApi<object>("UpdateUser", async () =>
        {
            // First get existing user
            var userRecord = CreateRecord("User");
            if (userRecord == null)
                return BridgeResult<object>.Fail("Could not create MT5 user record object");

            var getResult = InvokeMethod("UserGet", (ulong)request.Login, userRecord);
            if (!IsRetCodeSuccess(getResult))
                return BridgeResult<object>.Fail($"UserGet failed: {getResult}", 404);

            // Update requested fields
            if (request.Leverage.HasValue)
                SetProperty(userRecord, "Leverage", (uint)request.Leverage.Value);
            if (request.Group != null)
                SetProperty(userRecord, "Group", request.Group);

            var result = InvokeMethod("UserUpdate", userRecord);
            if (!IsRetCodeSuccess(result))
                return BridgeResult<object>.Fail($"UserUpdate failed: {result}", 400);

            return BridgeResult<object>.Ok(new { success = true });
        });
    }

    public async Task<BridgeResult<object>> ChangePassword(ChangePasswordRequest request)
    {
        return await CallApi<object>("ChangePassword", async () =>
        {
            var result = InvokeMethod("UserPasswordChange",
                (ulong)request.Login, request.Password);
            if (!IsRetCodeSuccess(result))
                return BridgeResult<object>.Fail($"UserPasswordChange failed: {result}", 400);

            return BridgeResult<object>.Ok(new { success = true });
        });
    }

    // ─── Trade Operations ────────────────────────────────────

    public async Task<BridgeResult<BalanceResponse>> BalanceOperation(BalanceRequest request)
    {
        return await CallApi<BalanceResponse>("BalanceOperation", async () =>
        {
            // DealerBalance(login, balance, type, comment, out orderId)
            var result = InvokeMethod("DealerBalance",
                (ulong)request.Login, request.Balance, (uint)request.Type, request.Comment);

            if (!IsRetCodeSuccess(result))
                return BridgeResult<BalanceResponse>.Fail($"DealerBalance failed: {result}", 400);

            return BridgeResult<BalanceResponse>.Ok(new BalanceResponse
            {
                Order = DateTime.UtcNow.Ticks.ToString()
            });
        });
    }

    // ─── History Operations ──────────────────────────────────

    public async Task<BridgeResult<List<TradeRecord>>> GetHistory(long login, long? from, long? to)
    {
        return await CallApi<List<TradeRecord>>("GetHistory", async () =>
        {
            // For now, return empty list if the method signature doesn't match
            // The exact API depends on the SDK version
            var trades = new List<TradeRecord>();

            try
            {
                var fromTime = from ?? DateTimeOffset.UtcNow.AddDays(-30).ToUnixTimeSeconds();
                var toTime = to ?? DateTimeOffset.UtcNow.ToUnixTimeSeconds();

                // Try to call HistoryGet or DealGet
                // Signature varies: HistoryGet(login, from, to, out deals)
                var historyMethod = FindApiMethod("HistoryGet", "DealGet", "DealRequest");
                if (historyMethod != null)
                {
                    _logger.LogInformation("Found history method: {Name} with {Count} params",
                        historyMethod.Name, historyMethod.GetParameters().Length);
                    // Implementation depends on actual SDK method signature
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error getting trade history");
            }

            return BridgeResult<List<TradeRecord>>.Ok(trades);
        });
    }

    public async Task<BridgeResult<List<TradeRecord>>> GetPositions(long login)
    {
        return await CallApi<List<TradeRecord>>("GetPositions", async () =>
        {
            var positions = new List<TradeRecord>();

            try
            {
                var posMethod = FindApiMethod("PositionGet", "PositionRequest");
                if (posMethod != null)
                {
                    _logger.LogInformation("Found position method: {Name}", posMethod.Name);
                    // Implementation depends on actual SDK method signature
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error getting positions");
            }

            return BridgeResult<List<TradeRecord>>.Ok(positions);
        });
    }

    // ─── Group Operations ────────────────────────────────────

    public async Task<BridgeResult<object>> GetGroupTotal()
    {
        return await CallApi<object>("GetGroupTotal", async () =>
        {
            try
            {
                var totalMethod = FindApiMethod("GroupTotal");
                if (totalMethod != null)
                {
                    var args = new object?[totalMethod.GetParameters().Length];
                    for (int i = 0; i < args.Length; i++)
                    {
                        if (totalMethod.GetParameters()[i].IsOut)
                            args[i] = (uint)0;
                    }
                    var result = totalMethod.Invoke(_managerApi, args);

                    // Find the out parameter with the total
                    for (int i = 0; i < args.Length; i++)
                    {
                        if (totalMethod.GetParameters()[i].IsOut)
                            return BridgeResult<object>.Ok(new { Total = args[i] });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error getting group total");
            }

            return BridgeResult<object>.Ok(new { Total = 0 });
        });
    }

    public async Task<BridgeResult<List<GroupInfo>>> GetAllGroups()
    {
        return await CallApi<List<GroupInfo>>("GetAllGroups", async () =>
        {
            var groups = new List<GroupInfo>();

            try
            {
                // Try GroupNext pattern: loop calling GroupNext(pos, group) until it returns error
                var groupRecord = CreateRecord("Group");
                if (groupRecord != null)
                {
                    for (uint i = 0; i < 1000; i++) // Safety limit
                    {
                        var result = InvokeMethod("GroupNext", i, groupRecord);
                        if (!IsRetCodeSuccess(result)) break;

                        var name = GetProperty<string>(groupRecord, "Group") ??
                                   GetProperty<string>(groupRecord, "Name") ?? "";
                        var desc = GetProperty<string>(groupRecord, "Description");

                        if (!string.IsNullOrEmpty(name))
                            groups.Add(new GroupInfo { Group = name, Description = desc });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error getting groups");
            }

            return BridgeResult<List<GroupInfo>>.Ok(groups);
        });
    }

    // ─── Helper Methods ──────────────────────────────────────

    private async Task<BridgeResult<T>> CallApi<T>(string operation, Func<Task<BridgeResult<T>>> action)
    {
        if (!_connected || _managerApi == null)
            return BridgeResult<T>.Unavailable();

        Interlocked.Increment(ref _totalRequests);
        await _apiLock.WaitAsync();
        try
        {
            return await action();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in {Operation}", operation);
            _lastError = $"{operation}: {ex.Message}";
            return BridgeResult<T>.Fail($"{operation} failed: {ex.Message}");
        }
        finally
        {
            _apiLock.Release();
        }
    }

    private string? FindManagerDll()
    {
        // MetaQuotes SDK names the .NET wrapper "MetaQuotes.MT5ManagerAPI64.dll"
        // Search for both the official name and legacy name
        var dllNames = new[] { "MetaQuotes.MT5ManagerAPI64.dll", "MT5ManagerAPI.NET.dll" };
        var searchDirs = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "libs"),
            AppContext.BaseDirectory,
            Path.Combine(AppContext.BaseDirectory, "..", "libs"),
            @"C:\MetaTrader5SDK\Libs",
        };

        foreach (var dir in searchDirs)
        {
            foreach (var dll in dllNames)
            {
                var path = Path.Combine(dir, dll);
                if (File.Exists(path))
                {
                    _logger.LogInformation("Found MT5 Manager API DLL at: {Path}", path);
                    return path;
                }
            }
        }

        _logger.LogError("MetaQuotes.MT5ManagerAPI64.dll not found in: {Paths}",
            string.Join(", ", searchDirs));
        return null;
    }

    private Type? FindType(Assembly assembly, string nameContains)
    {
        return assembly.GetExportedTypes()
            .FirstOrDefault(t => t.Name.Contains(nameContains, StringComparison.OrdinalIgnoreCase));
    }

    private MethodInfo? FindApiMethod(params string[] namePatterns)
    {
        if (_managerApi == null) return null;
        var methods = _managerApi.GetType().GetMethods();
        foreach (var pattern in namePatterns)
        {
            var method = methods.FirstOrDefault(m =>
                m.Name.Equals(pattern, StringComparison.OrdinalIgnoreCase));
            if (method != null) return method;
        }
        return null;
    }

    private object? InvokeMethod(string methodName, params object?[] args)
    {
        if (_managerApi == null) return null;
        var method = _managerApi.GetType().GetMethods()
            .FirstOrDefault(m => m.Name.Equals(methodName, StringComparison.OrdinalIgnoreCase)
                              && m.GetParameters().Length >= args.Length);

        if (method == null)
        {
            _logger.LogWarning("Method {Name} not found on Manager API. Available: {Methods}",
                methodName,
                string.Join(", ", _managerApi.GetType().GetMethods().Select(m => m.Name).Distinct().Take(30)));
            return null;
        }

        // Pad args if method expects more parameters (e.g., out params)
        var parameters = method.GetParameters();
        if (parameters.Length > args.Length)
        {
            var paddedArgs = new object?[parameters.Length];
            Array.Copy(args, paddedArgs, args.Length);
            for (int i = args.Length; i < parameters.Length; i++)
            {
                if (parameters[i].IsOut)
                    paddedArgs[i] = parameters[i].ParameterType.IsByRef
                        ? Activator.CreateInstance(parameters[i].ParameterType.GetElementType()!)
                        : null;
            }
            args = paddedArgs;
        }

        return method.Invoke(_managerApi, args);
    }

    private object? CreateRecord(string recordType)
    {
        if (_managerApi == null) return null;

        // Try to find a creation method for the record type
        var createMethod = _managerApi.GetType().GetMethods()
            .FirstOrDefault(m => m.Name.Contains($"{recordType}Create", StringComparison.OrdinalIgnoreCase));

        if (createMethod != null)
        {
            var args = new object?[createMethod.GetParameters().Length];
            var result = createMethod.Invoke(_managerApi, args);
            // Check if it returns the record or puts it in an out param
            if (result != null && result.GetType().Name.Contains(recordType))
                return result;
            for (int i = 0; i < args.Length; i++)
                if (args[i] != null && args[i]!.GetType().Name.Contains(recordType))
                    return args[i];
            return result;
        }

        // Fallback: try to find and instantiate the interface/class directly
        if (_managerAssembly != null)
        {
            var recordClass = _managerAssembly.GetExportedTypes()
                .FirstOrDefault(t => t.Name.Contains($"MT{recordType}", StringComparison.OrdinalIgnoreCase)
                                  && t.IsClass && !t.IsAbstract);
            if (recordClass != null)
                return Activator.CreateInstance(recordClass);
        }

        _logger.LogWarning("Could not create {RecordType} record object", recordType);
        return null;
    }

    private void SetProperty(object obj, string propertyName, object? value)
    {
        var prop = obj.GetType().GetProperty(propertyName,
            BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
        if (prop != null && prop.CanWrite)
        {
            prop.SetValue(obj, Convert.ChangeType(value, prop.PropertyType));
        }
        else
        {
            // Try method-based setter (some MT5 APIs use Set* methods)
            var setter = obj.GetType().GetMethod($"Set{propertyName}",
                BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
            setter?.Invoke(obj, new[] { value });
        }
    }

    private T? GetProperty<T>(object obj, string propertyName)
    {
        var prop = obj.GetType().GetProperty(propertyName,
            BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
        if (prop != null)
        {
            var val = prop.GetValue(obj);
            if (val is T typed) return typed;
            try { return (T)Convert.ChangeType(val, typeof(T)); } catch { }
        }
        return default;
    }

    private UserResponse MapUserResponse(object userRecord) => new()
    {
        Login = (GetProperty<ulong>(userRecord, "Login") ?? 0UL).ToString(),
        Name = GetProperty<string>(userRecord, "Name") ?? "",
        Group = GetProperty<string>(userRecord, "Group") ?? "",
        Leverage = $"1:{GetProperty<uint>(userRecord, "Leverage") ?? 100U}",
        Balance = GetProperty<double>(userRecord, "Balance") ?? 0.0,
        Equity = GetProperty<double>(userRecord, "Equity") ?? 0.0,
        Margin = GetProperty<double>(userRecord, "Margin") ?? 0.0,
        FreeMargin = GetProperty<double>(userRecord, "MarginFree") ??
                     GetProperty<double>(userRecord, "FreeMargin") ?? 0.0,
        Currency = GetProperty<string>(userRecord, "CurrencyDeposit") ??
                   GetProperty<string>(userRecord, "Currency") ?? "USD",
        Registration = GetProperty<long>(userRecord, "Registration") is long regTime && regTime > 0
            ? DateTimeOffset.FromUnixTimeSeconds(regTime).UtcDateTime.ToString("o")
            : DateTime.UtcNow.ToString("o")
    };

    private static bool IsRetCodeSuccess(object? retCode)
    {
        if (retCode == null) return false;
        var str = retCode.ToString() ?? "";
        // MT5 return code 0 = success (MT_RET_OK)
        if (str == "0" || str == "MT_RET_OK") return true;
        if (str.Contains("OK", StringComparison.OrdinalIgnoreCase)) return true;
        try { return Convert.ToInt64(retCode) == 0; } catch { return false; }
    }

    public void Dispose()
    {
        Disconnect();
        _apiLock.Dispose();
    }
}
